package model;

import java.util.Date;

import otherCode.NewBooking;
import util.Cin;

public class Test {

	public static void main(String[] args) {
		
/*
	Date date = new Date(2016, 11, 19);
	Date date2 = new Date(2016, 11, 18);

System.out.println(date.compareTo(date2));
	*/

		Customer customer = new Customer("Alex", 1, 22, 29844, 1245, "adre", "@");
		Customer customer1 = new Customer("Bogdan", 2, 22, 29844, 1245, "adre", "@");
		Customer customer2 = new Customer("Marian", 3, 22, 29844, 1245, "adre", "@");
		Customer customer3 = new Customer("Tomas", 4, 22, 29844, 1245, "adre", "@");
		
		Date startDate = new Date(2016, 1, 5);
		Date startDate1 = new Date(2016, 2, 10);
		Date startDate2= new Date(2016, 3, 15);
		Date startDate3 = new Date(2016, 4, 20);
		
		Date endDate = new Date(2016, 1, 10);
		Date endDate1 = new Date(2016, 2, 20);
		Date endDate2= new Date(2016, 3, 25);
		Date endDate3 = new Date(2016, 4, 22);
		
		
		Van van = new Van("A", "AAA", 100, "AX123", 24, true);
		FamilyCar car = new FamilyCar("Opel", "x", 200, "ZZ!@#");
		FamilyCar car2 = new FamilyCar("VW", "P!", 300, "qw1234");
		MovingTruck truck = new MovingTruck("DAF", "223", 1000, "FL123", "24T", 100000);
		
		
		
		Booking booking = new Booking(customer, 200, startDate, endDate, "Horsens", "Arhus", van);
		Booking booking1 = new Booking(customer1, 200, startDate1, endDate1, "Horsens", "Vejle", car);
		Booking booking2 = new Booking(customer2, 200, startDate2, endDate2, "Horsens", "Skade", car2);
		Booking booking3 = new Booking(customer3, 200, startDate3, endDate3, "Horsens", "Viby", truck);
		BookingManager bm = new BookingManager();
		
		
		
		bm.addBooking(booking);
		bm.addBooking(booking1);
		bm.addBooking(booking2);
		bm.addBooking(booking3);
		
		Date d1 = new Date(2000, 1, 1);
		Date d2 = new Date(2000, 3, 3);

	NewBooking n = new NewBooking();
	
	//System.out.println(bm.getListOfBookingsInPeriod(startDate, endDate2));
	//	System.out.println(bm.getAvailableVehiclesInPeriodByType("Family Car", d1, d2));
	}

}
