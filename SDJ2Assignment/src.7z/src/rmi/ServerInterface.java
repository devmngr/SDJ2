package rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface ServerInterface<T> extends Remote
{
    String toUpperCase(String msg, Object client) 
                                      throws RemoteException;
    public void add(T element,Object client) throws RemoteException;
	public T remove(T element,Object client) throws RemoteException;
	public boolean contains(T element) throws RemoteException;
	//following 2 methods should be implemented for every tipe of data
	public int sizeStringList() throws RemoteException;
	public ArrayList<String> getAllStrings()throws RemoteException;
}

