package view;

public class StartMain {

	public static void main(String[] args) {

		ClientConsole console = new ClientConsole();

	}

}
